-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2018 at 07:42 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kedai_java`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `struk`
-- (See below for the actual view)
--
CREATE TABLE `struk` (
`id_transaksi` varchar(20)
,`nama_menu` varchar(100)
,`harga_menu` int(10)
,`jumlah_beli` int(10)
,`total_beli` int(10)
,`bayar` int(10)
,`kembalian` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `strukk`
-- (See below for the actual view)
--
CREATE TABLE `strukk` (
`nama_menu` varchar(100)
,`harga_menu` int(10)
,`jumlah_beli` int(10)
,`total` int(10)
,`total_beli` int(10)
,`bayar` int(10)
,`kembalian` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `tb_fix`
--

CREATE TABLE `tb_fix` (
  `id_transaksi` varchar(20) NOT NULL,
  `total_beli` int(10) NOT NULL,
  `bayar` int(10) NOT NULL,
  `kembalian` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_fix`
--

INSERT INTO `tb_fix` (`id_transaksi`, `total_beli`, `bayar`, `kembalian`) VALUES
('PR0002', 8000, 10000, 2000),
('PR0003', 21000, 25000, 4000),
('PR0004', 49000, 50000, 1000),
('PR0006', 37000, 40000, 3000),
('PR0007', 44000, 50000, 6000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kasir`
--

CREATE TABLE `tb_kasir` (
  `id_kasir` varchar(50) NOT NULL,
  `nama_kasir` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `keterangan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kasir`
--

INSERT INTO `tb_kasir` (`id_kasir`, `nama_kasir`, `username`, `password`, `alamat`, `keterangan`) VALUES
('KS001', 'Paijo', 'paijo', 'kasir', 'Jl Wangun', 'Masuk'),
('KS002', 'Abil Muhamad', 'kasir', 'kasir', 'Jl. Raya Puncak Cisarua Bogor', 'Masuk');

-- --------------------------------------------------------

--
-- Table structure for table `tb_keranjang`
--

CREATE TABLE `tb_keranjang` (
  `id_transaksi` varchar(50) NOT NULL,
  `id_menu` varchar(10) NOT NULL,
  `nama_menu` varchar(20) NOT NULL,
  `harga_menu` int(6) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_keranjang`
--

INSERT INTO `tb_keranjang` (`id_transaksi`, `id_menu`, `nama_menu`, `harga_menu`, `jumlah_beli`, `total`, `status`) VALUES
('PR0002', 'MN004', 'Seblak', 8000, 1, 8000, 1),
('PR0003', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000, 1),
('PR0003', 'MN004', 'Seblak', 8000, 2, 16000, 1),
('PR0004', 'MN004', 'Double Espresso', 10000, 2, 20000, 1),
('PR0005', 'MN002', 'Kopi Arabik', 12000, 2, 24000, 1),
('PR0004', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000, 1),
('PR0006', 'MN004', 'Double Espresso', 10000, 2, 20000, 1),
('PR0006', 'MN002', 'Kopi Arabika', 12000, 1, 12000, 1),
('PR0006', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000, 1),
('PR0007', 'MN002', 'Kopi Arabika', 12000, 2, 24000, 1),
('PR0007', 'MN004', 'Double Espresso', 10000, 2, 20000, 1);

--
-- Triggers `tb_keranjang`
--
DELIMITER $$
CREATE TRIGGER `batal` AFTER DELETE ON `tb_keranjang` FOR EACH ROW UPDATE tb_menu
SET stok = stok + OLD.jumlah_beli
WHERE id_menu = OLD.id_menu
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `beli` AFTER INSERT ON `tb_keranjang` FOR EACH ROW BEGIN
UPDATE tb_menu SET stok = stok - new.jumlah_beli
WHERE id_menu = new.id_menu;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `beli2` AFTER UPDATE ON `tb_keranjang` FOR EACH ROW BEGIN
UPDATE tb_menu SET stok = stok - new.jumlah_beli + old.jumlah_beli
WHERE id_menu = new.id_menu;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_menu`
--

CREATE TABLE `tb_menu` (
  `id_menu` varchar(10) NOT NULL,
  `menu` enum('Makanan','Minuman') NOT NULL,
  `nama_menu` varchar(20) NOT NULL,
  `harga_menu` int(6) NOT NULL,
  `stok` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_menu`
--

INSERT INTO `tb_menu` (`id_menu`, `menu`, `nama_menu`, `harga_menu`, `stok`) VALUES
('MN001', 'Minuman', 'Kopi Gayo', 15000, 13),
('MN002', 'Minuman', 'Kopi Arabika', 12000, 10),
('MN003', 'Makanan', 'Kue Cubit Green Tea ', 5000, 13),
('MN004', 'Minuman', 'Double Espresso', 10000, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_kasir` varchar(20) DEFAULT NULL,
  `id_transaksi` varchar(20) DEFAULT NULL,
  `id_menu` varchar(10) NOT NULL,
  `nama_menu` varchar(100) NOT NULL,
  `harga_menu` int(10) NOT NULL,
  `jumlah_beli` int(10) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_kasir`, `id_transaksi`, `id_menu`, `nama_menu`, `harga_menu`, `jumlah_beli`, `total`) VALUES
('KS002', 'PR0003', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000),
('KS002', 'PR0005', 'MN002', 'Kopi Arabik', 12000, 2, 24000),
('KS002', 'PR0004', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000),
('KS002', 'PR0006', 'MN004', 'Double Espresso', 10000, 2, 20000),
('KS002', 'PR0006', 'MN002', 'Kopi Arabika', 12000, 1, 12000),
('KS002', 'PR0006', 'MN003', 'Kue Cubit Green Tea ', 5000, 1, 5000),
('KS002', 'PR0007', 'MN002', 'Kopi Arabika', 12000, 2, 24000),
('KS002', 'PR0007', 'MN004', 'Double Espresso', 10000, 2, 20000);

-- --------------------------------------------------------

--
-- Structure for view `struk`
--
DROP TABLE IF EXISTS `struk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `struk`  AS  select `tb_transaksi`.`id_transaksi` AS `id_transaksi`,`tb_transaksi`.`nama_menu` AS `nama_menu`,`tb_transaksi`.`harga_menu` AS `harga_menu`,`tb_transaksi`.`jumlah_beli` AS `jumlah_beli`,`tb_fix`.`total_beli` AS `total_beli`,`tb_fix`.`bayar` AS `bayar`,`tb_fix`.`kembalian` AS `kembalian` from (`tb_transaksi` join `tb_fix` on((`tb_transaksi`.`id_transaksi` = `tb_fix`.`id_transaksi`))) ;

-- --------------------------------------------------------

--
-- Structure for view `strukk`
--
DROP TABLE IF EXISTS `strukk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `strukk`  AS  select `tb_transaksi`.`nama_menu` AS `nama_menu`,`tb_transaksi`.`harga_menu` AS `harga_menu`,`tb_transaksi`.`jumlah_beli` AS `jumlah_beli`,`tb_transaksi`.`total` AS `total`,`tb_fix`.`total_beli` AS `total_beli`,`tb_fix`.`bayar` AS `bayar`,`tb_fix`.`kembalian` AS `kembalian` from (`tb_transaksi` join `tb_fix` on((`tb_transaksi`.`id_transaksi` = `tb_fix`.`id_transaksi`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD PRIMARY KEY (`id_menu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
